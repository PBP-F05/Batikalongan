from django import forms
from gallery.models import GalleryEntry

class GalleryEntryForm(forms.ModelForm):
    class Meta:
        model = GalleryEntry
        fields = ['nama_batik', 'deskripsi', 'makna', 'asal_usul', 'foto']
        widgets = {
            'nama_batik': forms.TextInput(attrs={
                'class': 'w-full border-2 border-[#D88E30] rounded-lg p-3',
                'placeholder': 'Masukkan nama batik'
            }),
            'deskripsi': forms.Textarea(attrs={
                'class': 'w-full border-2 border-[#D88E30] rounded-lg p-3',
                'placeholder': 'Masukkan deskripsi batik'
            }),
            'makna': forms.Textarea(attrs={
                'class': 'w-full border-2 border-[#D88E30] rounded-lg p-3',
                'placeholder': 'Masukkan makna batik'
            }),
            'asal_usul': forms.Textarea(attrs={
                'class': 'w-full border-2 border-[#D88E30] rounded-lg p-3',
                'placeholder': 'Masukkan asal-usul batik'
            }),
            'foto': forms.ClearableFileInput(attrs={
                'class': 'w-full border-2 border-dashed border-[#D88E30] rounded-lg p-3',
            }),
        }
