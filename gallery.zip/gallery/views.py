from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import GalleryEntry
from .forms import GalleryEntryForm
from django.core.paginator import Paginator
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

def show_gallery(request):
    gallery_entries = GalleryEntry.objects.all()
    paginator = Paginator(gallery_entries, 6)  # Paginate with 6 entries per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'gallery.html', {'page_obj': page_obj})

@csrf_exempt
@require_POST
def add_gallery_entry_ajax(request):
    form = GalleryEntryForm(request.POST, request.FILES)
    if form.is_valid():
        entry = form.save()
        # Render the new entry using the cards_gallery_entry.html template
        entry_html = render_to_string('cards_gallery_entry.html', {'item': entry})
        return JsonResponse({'html': entry_html, 'id': str(entry.id)}, status=201)
    return JsonResponse({'error': 'Invalid data'}, status=400)

@csrf_exempt
@require_POST
def edit_gallery_entry_ajax(request, id):
    entry = get_object_or_404(GalleryEntry, id=id)
    form = GalleryEntryForm(request.POST, request.FILES, instance=entry)
    if form.is_valid():
        entry = form.save()
        # Render the updated entry using the cards_gallery_entry.html template
        entry_html = render_to_string('cards_gallery_entry.html', {'item': entry})
        return JsonResponse({'html': entry_html, 'id': str(entry.id)}, status=200)
    return JsonResponse({'error': 'Invalid data'}, status=400)
    
@csrf_exempt
@require_POST
def delete_gallery_entry_ajax(request, id):
    entry = get_object_or_404(GalleryEntry, id=id)
    entry.delete()
    return JsonResponse({"message": "Entry deleted"}, status=200)
