from django.urls import path
from . import views

app_name = 'gallery'

urlpatterns = [
    path('', views.show_gallery, name='show_gallery'),
    path('add-ajax/', views.add_gallery_entry_ajax, name='add_gallery_entry_ajax'),
    path('edit-ajax/<uuid:id>/', views.edit_gallery_entry_ajax, name='edit_gallery_entry_ajax'),
    path('delete-ajax/<uuid:id>/', views.delete_gallery_entry_ajax, name='delete_gallery_entry_ajax'),
]
